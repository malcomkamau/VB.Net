For the executable file, navigate to 'completeBuilt(exe file)' directory.
For the source code, navigate to 'completeUnbuilt' directory.
